package employeesystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EmployeeSystem {

    public static class Employee {
      
    // Method to display Employee details
    public void displayEmployeeDetails() {
        System.out.println("---------------------------");
        System.out.println("Employee Number: " + employeeNumber);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("Birthday: " + birthday);
        System.out.println("Address: " + address);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("SSS Number: " + sssNumber);
        System.out.println("TIN Number: " + tinNumber);
        System.out.println("Pag-ibig Number: " + pagIbigNumber);
        System.out.println("Status: " + status);
        System.out.println("Position: " + position);
        System.out.println("Immediate Supervisor: " + immediateSupervisor);
        System.out.println("Basic Salary: " + basicSalary);
        System.out.println("Rice Subsidy: " + riceSubsidy);
        System.out.println("Hourly Rate: " + hourlyRate);
        System.out.println("---------------------------");
    }

    // Method to display Employee details
    public void displayEmployeeListDetails() {
        System.out.println("---------------------------");
        System.out.println("Employee Number: " + employeeNumber);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("---------------------------");
    }
}

class EmployeeManager {
    private List<Employee> employees;

    public EmployeeManager() {
        employees = new ArrayList<>();
    }

    // Create
    public void addEmployee(Employee employee) {
        employees.add(employee);
        System.out.println("Employee added: " + employee.getEmployeeName());
    }

    // Read (Search)
    public void searchEmployee(String employeeNumber) {
        for (Employee employee : employees) {
            if (employee.getEmployeeNumber().equals(employeeNumber)) {
                employee.displayEmployeeDetails();
                handleEmployeeActions(employee);
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    public void listEmployees() {
        if (employees.isEmpty()) {
            System.out.println("No employees to display.");
            return;
        }
        for (Employee employee : employees) {
            employee.displayEmployeeListDetails();
            System.out.println();
        }
    }

    // Update
    private void updateEmployee(Employee employee, String employeeName, String birthday, String address, String phoneNumber, String sssNumber, String tinNumber, String pagIbigNumber,
                                String status, String position, String immediateSupervisor, String basicSalary, String riceSubsidy, String hourlyRate) {
        employee.setEmployeeName(employeeName);
        employee.setBirthday(birthday);
        employee.setAddress(address);
        employee.setPhoneNumber(phoneNumber);
        employee.setSssNumber(sssNumber);
        employee.setTinNumber(tinNumber);
        employee.setPagIbigNumber(pagIbigNumber);
        employee.setStatus(status);
        employee.setPosition(position);
        employee.setImmediateSupervisor(immediateSupervisor);
        employee.setBasicSalary(basicSalary);
        employee.setRiceSubsidy(riceSubsidy);
        employee.setHourlyRate(hourlyRate);
        System.out.println("Employee updated: " + employee.getEmployeeName());
    }

    // Delete
    private void deleteEmployee(Employee employee) {
        employees.remove(employee);
        System.out.println("Employee deleted: " + employee.getEmployeeName());
    }

    // Handle Employee Actions
    private void handleEmployeeActions(Employee employee) {
        System.out.println("Select an action: 1. Update, 2. Delete, 3. No Action");
        int action = 0; // Get action from user
        switch (action) {
            case 1:
                // Get new details from user
                updateEmployee(employee, "", "", "", "", "", "", "", "", "", "", "", "", "");
                break;
            case 2:
                deleteEmployee(employee);
                break;
            case 3:
                System.out.println("No action taken.");
                break;
            default:
                System.out.println("Invalid action.");
        }
    }

    // View Employee Attendance (placeholder)
    public void viewEmployeeAttendance(String employeeNumber) {
        for (Employee employee : employees) {
            if (employee.getEmployeeNumber().equals(employeeNumber)) {
                System.out.println("Displaying attendance for employee: " + employee.getEmployeeName());
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    // View Employee Salary (placeholder)
    public void viewEmployeeSalary(String employeeNumber) {
        for (Employee employee : employees) {
            if (employee.getEmployeeNumber().equals(employeeNumber)) {
                System.out.println("Displaying salary for employee: " + employee.getEmployeeName());
                System.out.println("Salary: " + employee.getBasicSalary());
                return;
            }
        }
        System.out.println("Employee not found.");
    }

    // Menu
    public void menu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nMenu:");
            System.out.println("1. Add Employee");
            System.out.println("2. List Employees");
            System.out.println("3. Search Employee");
            System.out.println("4. View Employee Attendance");
            System.out.println("5. View Employee Salary");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter employee number: ");
                    String employeeNumber = scanner.next();

                    System.out.print("Enter employee name: ");
                    String employeeName = scanner.next();

                    System.out.print("Enter birthday: ");
                    String birthday = scanner.next();

                    System.out.print("Enter address: ");
                    String address = scanner.next();

                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.next();

                    System.out.print("Enter SSS number: ");
                    String sssNumber = scanner.next();

                    System.out.print("Enter TIN number: ");
                    String tinNumber = scanner.next();

                    System.out.print("Enter Pag-ibig number: ");
                    String pagIbigNumber = scanner.next();

                    System.out.print("Enter status: ");
                    String status = scanner.next();

                    System.out.print("Enter position: ");
                    String position = scanner.next();

                    System.out.print("Enter immediate supervisor: ");
                    String immediateSupervisor = scanner.next();

                    System.out.print("Enter basic salary: ");
                    String basicSalary = scanner.next();

                    System.out.print("Enter rice subsidy: ");
                    String riceSubsidy = scanner.next();

                    System.out.print("Enter hourly rate: ");
                    String hourlyRate = scanner.next();

                    Employee newEmployee = new Employee(employeeNumber, employeeName, birthday, address, phoneNumber, sssNumber, tinNumber, pagIbigNumber,
                            status, position, immediateSupervisor, basicSalary, riceSubsidy, hourlyRate);
                    addEmployee(newEmployee);
                    break;

                case 2:
                    listEmployees();
                    break;

                case 3:
                    System.out.print("Enter employee number to search: ");
                    String searchNumber = scanner.next();
                    searchEmployee(searchNumber);
                    break;

                case 4:
                    System.out.print("Enter employee number to view attendance: ");
                    String attendanceNumber = scanner.next();
                    viewEmployeeAttendance(attendanceNumber);
                    break;

                case 5:
                    System.out.print("Enter employee number to view salary: ");
                    String salaryNumber = scanner.next();
                    viewEmployeeSalary(salaryNumber);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }
}

public class MotorPhVersion2 {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();
        manager.menu();
    }
}

