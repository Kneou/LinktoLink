package data;

public class Employee {
    private String employeeId;
    private String lastName;
    private String firstName;
    private String birthday;
    private String address;
    private String phoneNumber;
    private String sssNumber;
    private String philhealthNumber;
    private String tinNumber;
    private String pagIbigNumber;
    private String status;
    private String position;
    private String immediateSupervisor;
    private String basicSalary;
    private String riceSubsidy;
    private String phoneAllowance;
    private String clothingAllowance;
    private String grossSemiMonthlyRate;
    private String hourlyRate;

//    public Employee(String employeeId, String lastName, String firstName, String birthday, String address, String phoneNumber, String sssNumber, String philhealthNumber, String tinNumber, String pagIbigNumber, String status, String position, String immediateSupervisor, String basicSalary, String riceSubsidy, String phoneAllowance, String clothingAllowance, String grossSemiMonthlyRate, String hourlyRate) {
//        this.employeeId = employeeId;
//        this.lastName = lastName;
//        this.firstName = firstName;
//        this.birthday = birthday;
//        this.address = address;
//        this.phoneNumber = phoneNumber;
//        this.sssNumber = sssNumber;
//        this.philhealthNumber = philhealthNumber;
//        this.tinNumber = tinNumber;
//        this.pagIbigNumber = pagIbigNumber;
//        this.status = status;
//        this.position = position;
//        this.immediateSupervisor = immediateSupervisor;
//        this.basicSalary = basicSalary;
//        this.riceSubsidy = riceSubsidy;
//        this.phoneAllowance = phoneAllowance;
//        this.clothingAllowance = clothingAllowance;
//        this.grossSemiMonthlyRate = grossSemiMonthlyRate;
//        this.hourlyRate = hourlyRate;
//    }

    // Getters and setters
    public String getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(String employeeId) {
        this.employeeId = employeeId;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getSssNumber() {
        return sssNumber;
    }

    public void setSssNumber(String sssNumber) {
        this.sssNumber = sssNumber;
    }

    public String getPhilhealthNumber() {
        return philhealthNumber;
    }

    public void setPhilhealthNumber(String philhealthNumber) {
        this.philhealthNumber = philhealthNumber;
    }

    public String getTinNumber() {
        return tinNumber;
    }

    public void setTinNumber(String tinNumber) {
        this.tinNumber = tinNumber;
    }

    public String getPagIbigNumber() {
        return pagIbigNumber;
    }

    public void setPagIbigNumber(String pagIbigNumber) {
        this.pagIbigNumber = pagIbigNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getImmediateSupervisor() {
        return immediateSupervisor;
    }

    public void setImmediateSupervisor(String immediateSupervisor) {
        this.immediateSupervisor = immediateSupervisor;
    }

    public String getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(String basicSalary) {
        this.basicSalary = basicSalary;
    }

    public String getRiceSubsidy() {
        return riceSubsidy;
    }

    public void setRiceSubsidy(String riceSubsidy) {
        this.riceSubsidy = riceSubsidy;
    }

    public String getPhoneAllowance() {
        return phoneAllowance;
    }

  public void setPhoneAllowance(String phoneAllowance) {
    this.phoneAllowance = phoneAllowance;
}

public String getGrossSemiMonthlyRate() {
    return grossSemiMonthlyRate;
}

public void setGrossSemiMonthlyRate(String grossSemiMonthlyRate) {
    this.grossSemiMonthlyRate = grossSemiMonthlyRate;
}

public String getClothingAllowance() {
    return clothingAllowance;
}

public void setClothingAllowance(String clothingAllowance) {
    this.clothingAllowance = clothingAllowance;
}

public String getHourlyRate() {
    return hourlyRate;
}

public void setHourlyRate(String hourlyRate) {
    this.hourlyRate = hourlyRate;
}


}